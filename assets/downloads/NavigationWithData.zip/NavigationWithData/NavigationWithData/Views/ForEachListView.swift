//
//  ForEachListView.swift
//  NavigationWithData
//
//  Created by Justin Bennett on 2022-10-10.
//

import SwiftUI

struct ForEachListView: View {
    @State var people = [Person]()
    
    func deleteItem(at offsets: IndexSet) {
        people.remove(atOffsets: offsets)
    }
    
    var body: some View {
        NavigationStack {
            List {

                ForEach(people) { person in
                   
                        NavigationLink(destination: PersonDetailView(person: person)) {
                       PersonListItemView(person: person)
                    }
                }.onDelete(perform: deleteItem)
                
                
            }
            .listStyle(.automatic)
            .navigationTitle("People (ForEach)")
            
        }
    }
}


struct ForEachListView_Previews: PreviewProvider {
    static var previews: some View {
        ForEachListView()
    }
}
