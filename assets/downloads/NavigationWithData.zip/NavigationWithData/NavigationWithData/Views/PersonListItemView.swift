//
//  PersonListItemView.swift
//  NavigationWithData
//
//  Created by Justin Bennett on 2022-10-10.
//

import SwiftUI

struct PersonListItemView: View {
    var person: Person
    var body: some View {
        
        HStack {
            VStack(alignment: .leading) {
                Text(person.fullName)
                    .font(.title3)
//                Text("Id: \(person.id)")
            }
            
            Spacer()
        }
        
    }
}

struct PersonListItemView_Previews: PreviewProvider {
    static var previews: some View {
        PersonListItemView(person: Person(firstName: "Test", lastName: "Teterson", email: "testy@test.com", id: 3))
    }
}
