//
//  ListView.swift
//  NavigationWithData
//
//  Created by Justin Bennett on 2022-10-10.
//

import SwiftUI

struct ListView: View {
    var people = [Person]()
    
    var body: some View {
        NavigationStack {

            List(people) { person in
               
                    NavigationLink(destination: PersonDetailView(person: person)) {
                        
                       PersonListItemView(person: person)
                }
                
            }.listStyle(.plain)
                .navigationTitle("People (List)")
                .navigationBarItems(leading: Button("Click") {
                    print("clicked")
                })
            
        }
    }
}


struct ListView_Previews: PreviewProvider {
    static var previews: some View {
        ListView()
    }
}
