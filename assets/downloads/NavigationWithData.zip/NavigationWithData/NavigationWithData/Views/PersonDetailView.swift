//
//  PersonDetailView.swift
//  NavigationWithData
//
//  Created by Justin Bennett on 2022-10-10.
//

import SwiftUI

struct PersonDetailView: View {
    var person: Person
    var body: some View {
            VStack(alignment: .leading) {
                Text(person.fullName)
                    .font(.title2)
                Text("Id: \(person.id)")
            }
            .navigationTitle(person.fullName)
            .navigationBarTitleDisplayMode(.inline)
    }
}

struct PersonDetailView_Previews: PreviewProvider {
    static var previews: some View {
        PersonDetailView(person: Person(firstName: "Test", lastName: "Teterson", email: "testy@test.com", id: 3))
    }
}
