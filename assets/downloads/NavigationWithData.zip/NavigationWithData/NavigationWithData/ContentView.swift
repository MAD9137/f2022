//
//  ContentView.swift
//  NavigationWithData
//
//  Created by Justin Bennett on 2022-10-10.
//

import SwiftUI


struct ContentView: View {
    var people = fetchTestData(filename: "people", objectType: Person.self)
    
    
    var body: some View {
        /// Plain old List View
//        ListView(people: people)
        
        /// ForEach List View with onDelete()
        ForEachListView(people: people)
    }
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
