//
//  NavigationWithDataApp.swift
//  NavigationWithData
//
//  Created by Justin Bennett on 2022-10-10.
//

import SwiftUI

@main
struct NavigationWithDataApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
