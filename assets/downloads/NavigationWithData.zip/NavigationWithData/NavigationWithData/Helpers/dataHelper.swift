//
//  dataHelper.swift
//  NavigationWithData
//
//  Created by Justin Bennett on 2022-10-10.
//

import Foundation

func fetchTestData<T: Decodable>(filename: String, objectType: T.Type) -> Array<T> {
    
    let obtype = objectType.self
    debugPrint(obtype)
    
    guard let path = Bundle.main.path(forResource: filename, ofType: "json") else {
        fatalError("Failed to locate \(filename) in bundle.")
    }
    
    
    guard let data = try? Data(contentsOf: URL(fileURLWithPath: path), options: .alwaysMapped) else {
        fatalError("Failed to load \(filename) from bundle.")
    }
    
    let decoder = JSONDecoder()
    
    guard let testData = try? decoder.decode([T].self, from: data) else {
        fatalError("Failed to decode \(filename) from bundle.")
    }
    
    return testData
}
