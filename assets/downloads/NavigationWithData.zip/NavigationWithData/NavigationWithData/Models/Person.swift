//
//  Person.swift
//  NavigationWithData
//
//  Created by Justin Bennett on 2022-10-10.
//

import Foundation


struct Person: Identifiable, Codable, Hashable {
    //MARK: Properties
    
    var firstName: String
    var lastName: String
    var email: String
    var id: Int
    
    var fullName: String {
        return "\(firstName) \(lastName)"
    }
    
    enum CodingKeys: String, CodingKey {
        case firstName = "first_name"
        case lastName = "last_name"
        case email
        case id
    }
    
}


